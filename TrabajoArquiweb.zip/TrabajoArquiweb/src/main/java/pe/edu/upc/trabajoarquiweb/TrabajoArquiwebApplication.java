package pe.edu.upc.trabajoarquiweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class    TrabajoArquiwebApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrabajoArquiwebApplication.class, args);
    }

}
