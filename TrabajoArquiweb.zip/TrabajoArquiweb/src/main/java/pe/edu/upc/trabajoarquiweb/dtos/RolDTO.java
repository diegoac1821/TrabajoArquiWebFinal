package pe.edu.upc.trabajoarquiweb.dtos;



public class RolDTO {


    private String role;
    private int id;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
