package pe.edu.upc.trabajoarquiweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoArquiwebApplicationTests {

    @Test
    void contextLoads() {
    }

}
